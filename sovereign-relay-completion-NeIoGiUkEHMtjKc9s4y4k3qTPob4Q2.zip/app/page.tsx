'use client'

import { useState } from 'react'
import { ArrowUpRight, Check, ChevronDown, Copy, LockKeyhole, Menu, Radio, ShieldCheck, X } from 'lucide-react'

const routes = [
  { name: 'Northstar / Core', status: 'Operational', latency: '18ms', color: 'bg-emerald-400' },
  { name: 'Atlas / Archive', status: 'Operational', latency: '42ms', color: 'bg-emerald-400' },
  { name: 'Helix / Fallback', status: 'Standby', latency: '—', color: 'bg-amber-300' },
]

export default function Page() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  const copyEndpoint = async () => {
    await navigator.clipboard?.writeText('relay://sovereign/northstar')
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#0b0d0d] text-[#e9ece8]">
      <div className="pointer-events-none fixed inset-0 opacity-40 [background-image:linear-gradient(rgba(210,227,218,.045)_1px,transparent_1px),linear-gradient(90deg,rgba(210,227,218,.045)_1px,transparent_1px)] [background-size:52px_52px]" />
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-6 lg:px-10">
        <a href="#top" className="flex items-center gap-3 text-sm font-semibold tracking-[0.2em] text-[#f3f5ef]">
          <span className="flex h-8 w-8 items-center justify-center border border-[#9bb4a2]/50 bg-[#111716]"><Radio size={15} className="text-[#a8d5b0]" /></span>
          SOVEREIGN<span className="text-[#a8d5b0]">RELAY</span>
        </a>
        <nav className="hidden items-center gap-8 text-xs uppercase tracking-[0.16em] text-[#8e9991] md:flex">
          <a href="#architecture" className="transition hover:text-white">Architecture</a>
          <a href="#status" className="transition hover:text-white">Status</a>
          <a href="#access" className="transition hover:text-white">Access</a>
        </nav>
        <button aria-label="Toggle menu" onClick={() => setMobileOpen(!mobileOpen)} className="border border-[#9bb4a2]/30 p-2 md:hidden">{mobileOpen ? <X size={18} /> : <Menu size={18} />}</button>
        <a href="#access" className="hidden border border-[#bdd5c0]/60 px-4 py-2 text-xs uppercase tracking-[0.14em] text-[#d6e9d9] transition hover:bg-[#b8d7bd] hover:text-[#0b0d0d] md:block">Request access</a>
      </header>
      {mobileOpen && <nav className="relative z-10 flex flex-col gap-5 border-y border-[#9bb4a2]/20 bg-[#101514] px-6 py-5 text-xs uppercase tracking-[0.16em] text-[#b8c5bb] md:hidden"><a href="#architecture" onClick={() => setMobileOpen(false)}>Architecture</a><a href="#status" onClick={() => setMobileOpen(false)}>Status</a><a href="#access" onClick={() => setMobileOpen(false)}>Access</a></nav>}

      <section id="top" className="relative z-0 mx-auto grid max-w-7xl items-center gap-16 px-6 pb-24 pt-20 lg:grid-cols-[1.05fr_.95fr] lg:px-10 lg:pb-36 lg:pt-28">
        <div>
          <div className="mb-7 flex items-center gap-3 text-[10px] uppercase tracking-[0.28em] text-[#a8d5b0]"><span className="h-1.5 w-1.5 rounded-full bg-[#a8d5b0] shadow-[0_0_14px_#a8d5b0]" />Private infrastructure, re-routed</div>
          <h1 className="max-w-3xl text-5xl font-medium leading-[.98] tracking-[-0.055em] text-[#f1f3ed] sm:text-7xl lg:text-[6.5rem]">Move data<br /><span className="text-[#a8d5b0]">on your terms.</span></h1>
          <p className="mt-8 max-w-lg text-base leading-7 text-[#9ba69f]">SovereignRelay gives critical systems a private, observable path between wherever your data lives and wherever it needs to go.</p>
          <div className="mt-10 flex flex-wrap gap-3"><a href="#access" className="inline-flex items-center gap-3 bg-[#b8d7bd] px-5 py-3 text-sm font-semibold text-[#0b0d0d] transition hover:bg-[#d5ecd8]">Open a relay <ArrowUpRight size={16} /></a><a href="#architecture" className="inline-flex items-center gap-3 border border-[#9bb4a2]/35 px-5 py-3 text-sm text-[#c6d1c9] transition hover:border-[#b8d7bd]">See architecture <ChevronDown size={16} /></a></div>
          <div className="mt-14 flex flex-wrap gap-x-8 gap-y-3 text-[10px] uppercase tracking-[0.2em] text-[#718077]"><span className="flex items-center gap-2"><LockKeyhole size={13} className="text-[#a8d5b0]" /> End-to-end encrypted</span><span className="flex items-center gap-2"><ShieldCheck size={13} className="text-[#a8d5b0]" /> No shared tenancy</span></div>
        </div>
        <div className="relative mx-auto w-full max-w-xl border border-[#9bb4a2]/25 bg-[#101514] p-4 shadow-2xl shadow-black/30">
          <div className="flex items-center justify-between border-b border-[#9bb4a2]/15 pb-4 text-[10px] uppercase tracking-[0.2em] text-[#7c8980]"><span>Relay console / 01</span><span className="flex items-center gap-2 text-[#a8d5b0]"><span className="h-1.5 w-1.5 rounded-full bg-[#a8d5b0]" />Live</span></div>
          <div className="grid grid-cols-2 gap-3 py-5"><div className="bg-[#171d1b] p-4"><p className="text-[10px] uppercase tracking-[.18em] text-[#748078]">Throughput</p><p className="mt-2 text-3xl tracking-tight">8.42 <span className="text-sm text-[#87968c]">TB</span></p><p className="mt-1 text-xs text-[#a8d5b0]">+12.8% this week</p></div><div className="bg-[#171d1b] p-4"><p className="text-[10px] uppercase tracking-[.18em] text-[#748078]">Integrity</p><p className="mt-2 text-3xl tracking-tight">99.99<span className="text-sm">%</span></p><p className="mt-1 text-xs text-[#a8d5b0]">All checks passing</p></div></div>
          <div className="border border-[#9bb4a2]/15 p-4"><div className="mb-5 flex items-center justify-between"><span className="text-xs text-[#d1d9d1]">Active routes</span><span className="text-[10px] uppercase tracking-[.16em] text-[#718077]">Last 24h</span></div>{routes.map((route) => <div key={route.name} className="flex items-center justify-between border-t border-[#9bb4a2]/10 py-3 text-xs"><span className="flex items-center gap-3"><span className={`h-1.5 w-1.5 rounded-full ${route.color}`} />{route.name}</span><span className="flex items-center gap-5 text-[#7d8a82]"><span>{route.status}</span><span className="w-8 text-right">{route.latency}</span></span></div>)}</div>
          <div className="mt-4 flex items-center justify-between bg-[#18231e] px-4 py-3"><code className="text-xs text-[#b8d7bd]">relay://sovereign/northstar</code><button onClick={copyEndpoint} aria-label="Copy endpoint" className="text-[#91ad98] hover:text-white">{copied ? <Check size={15} /> : <Copy size={15} />}</button></div>
        </div>
      </section>

      <section id="architecture" className="relative z-10 border-y border-[#9bb4a2]/15 bg-[#0e1211] px-6 py-20 lg:px-10"><div className="mx-auto max-w-7xl"><div className="mb-12 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="text-[10px] uppercase tracking-[.28em] text-[#a8d5b0]">The relay layer</p><h2 className="mt-4 max-w-xl text-3xl tracking-[-.04em] text-[#edf2eb] sm:text-5xl">Control the path.<br />Keep the context.</h2></div><p className="max-w-sm text-sm leading-6 text-[#87938b]">A deliberate network boundary for teams that cannot outsource the shape of their most important data.</p></div><div className="grid gap-px border border-[#9bb4a2]/15 bg-[#9bb4a2]/15 md:grid-cols-3">{[['01', 'Private by default', 'Your relay runs in an isolated environment with keys you control.'], ['02', 'Observable by design', 'Every handoff is traceable, measurable, and easy to interrogate.'], ['03', 'Resilient under pressure', 'Failover paths keep your operations moving when dependencies do not.']].map(([number, title, copy]) => <article key={number} className="bg-[#101514] p-7 sm:p-9"><span className="text-xs text-[#a8d5b0]">{number}</span><h3 className="mt-16 text-xl text-[#edf2eb]">{title}</h3><p className="mt-4 text-sm leading-6 text-[#87938b]">{copy}</p></article>)}</div></div></section>

      <section id="status" className="relative z-10 mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-[.8fr_1.2fr] lg:px-10"><div><p className="text-[10px] uppercase tracking-[.28em] text-[#a8d5b0]">Built for consequence</p><h2 className="mt-4 text-3xl tracking-[-.04em] sm:text-5xl">The infrastructure<br />between the lines.</h2></div><div className="grid gap-8 sm:grid-cols-2"><div><p className="text-4xl text-[#b8d7bd]">14</p><p className="mt-2 text-sm leading-6 text-[#87938b]">regions ready for deployment, with a single operating model.</p></div><div><p className="text-4xl text-[#b8d7bd]">0.4ms</p><p className="mt-2 text-sm leading-6 text-[#87938b]">median relay overhead at the edge of your network.</p></div><div><p className="text-4xl text-[#b8d7bd]">24/7</p><p className="mt-2 text-sm leading-6 text-[#87938b]">human escalation for the paths that cannot wait.</p></div><div><p className="text-4xl text-[#b8d7bd]">SOC 2</p><p className="mt-2 text-sm leading-6 text-[#87938b]">controls mapped from day one, not retrofitted at the end.</p></div></div></section>

      <section id="access" className="relative z-10 mx-6 mb-10 overflow-hidden border border-[#a8d5b0]/35 bg-[#b8d7bd] px-7 py-12 text-[#0b0d0d] sm:px-12 lg:mx-auto lg:max-w-7xl lg:py-16"><div className="relative z-10 flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><p className="text-[10px] uppercase tracking-[.28em] text-[#31503a]">Start with one path</p><h2 className="mt-4 max-w-2xl text-4xl font-medium tracking-[-.05em] sm:text-6xl">Make your next handoff sovereign.</h2></div><a href="mailto:access@sovereignrelay.dev" className="inline-flex w-fit items-center gap-3 border border-[#31503a]/40 px-5 py-3 text-sm font-semibold transition hover:bg-[#0b0d0d] hover:text-[#d9edda]">Request access <ArrowUpRight size={16} /></a></div></section>
      <footer className="relative z-10 mx-auto flex max-w-7xl flex-col gap-4 px-6 pb-8 text-[10px] uppercase tracking-[.18em] text-[#66736b] sm:flex-row sm:items-center sm:justify-between lg:px-10"><span>© 2026 SovereignRelay</span><span>Private infrastructure for public consequence</span></footer>
    </main>
  )
}
